import { extendTheme, ChakraProvider } from "@chakra-ui/react";
export const theme= extendTheme
